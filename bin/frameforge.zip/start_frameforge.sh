#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "启动 FrameForge 应用..."

"$DIR/frameforge"
